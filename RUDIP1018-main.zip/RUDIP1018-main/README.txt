GitHub JSON API Example Project 

Files included: 
- index.html : Browser-based view of GitHub JSON 
- fetch.js : JavaScript code to fetch JSON 
- test.py : Python code to fetch and print JSON 
- postman_collection.json : Import into Postman for testing 
- README.txt : This file 

GitHub JSON URL used: https://garvemodigum.github.io/garvmodigum/data.json